import streamlit as st
import pickle

# st.set_page_config(
#     layout= 'centered',
#     page_title= 'churn_prediction'
# )


def show1():
    CustomerId = st.text_input('Enter the customer id')

    Surname = st.text_input('Enter the Surname')

    CreditScore = st.number_input('Enter the CreditScore',0,900)

    geo_list = ['France', 'Spain', 'Germany']
    Geography = st.selectbox("What is the Geographical Location", options= geo_list, index = None)

    gender = ['Male','Female']
    Gender = st.radio("Pick your Gender",gender,  index = None)

    Age = st.slider("Age", 0, 100)

    Tenure = st.slider("Customer Tenure", 0, 15)

    Balance = st.number_input('Enter the Account Balance',0,150000)

    NumOfProducts = st.number_input("Number of Products",0,5)

    CreditCard = st.radio("Does the customer have credit card",["Yes","No"], index = None)
    if CreditCard == 'Yes':
        HasCrCard = 1
    else:
        HasCrCard = 0

    ActiveMember = st.radio("Is the customer Active Member",["Yes","No"],  index = None)
    if ActiveMember == 'Yes':
        IsActiveMember = 1
    else:
        IsActiveMember = 0

    EstimatedSalary = st.number_input("Customer Salary", 0, 200000)

    
    parameters =  {'CustomerId':CustomerId, 
            'Surname':Surname, 'CreditScore':CreditScore, 'Geography':Geography, 
             'Gender':Gender, 'Age':Age, 'Tenure':Tenure, 
             'Balance':Balance, 'NumOfProducts':NumOfProducts, 
              'HasCrCard':HasCrCard, 'IsActiveMember':IsActiveMember, 'EstimatedSalary': EstimatedSalary}

    return parameters

