import streamlit as st
import pandas as pd

# st.set_page_config(
#     layout= 'centered',
#     page_title= 'churn_prediction'
# )

def show2():
    uploaded_file = st.file_uploader("Enter the csv file")
    
    if(uploaded_file is not None):
        df_main = pd.read_csv(uploaded_file)
        return df_main