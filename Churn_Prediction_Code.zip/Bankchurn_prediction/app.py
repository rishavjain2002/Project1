import streamlit as st
from streamlit_option_menu import option_menu
import input_types.input_values as input_values
import input_types.input_csv as input_csv
import pickle
import predictions.values_predict as values_predict
import predictions.csv_predict as csv_predict



st.set_page_config(
    layout= 'centered',
    page_title= 'churn_prediction'
)

def local_css(file_name):
    with open(file_name) as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
local_css("style.css")

st.markdown(
    '<h1 class="centered-title">Bank Churn Prediction</h1>',
    unsafe_allow_html=True
)

with st.container():
    selected = option_menu(
        menu_title=None,
        options=['InputValues','InputCSV'],
        icons=['book','bar-chart'],
        orientation='horizontal'
    )

    if selected == 'InputValues':
        parameters1 = input_values.show1()  # Retrieve parameters1 from input_values module
        
        if st.button("Predict"):
            result = values_predict.predict_values(parameters1)  # Predict using parameters1
            st.write("Prediction Result:", result)
            if result == 0:
                st.write("Customer does not churn")
            else:
                st.write("Customer churn")


    if selected == 'InputCSV':
        dataframe_input = input_csv.show2()
        if dataframe_input is not None and not dataframe_input.empty:            
            st.write("DataFrame loaded successfully:")
            st.write(dataframe_input.head())
            
            Exited_prediction_prob = csv_predict.predict_csv(dataframe_input)
            
            if Exited_prediction_prob is not None:
                dataframe_input['Prob_0'] = [item[0] for item in Exited_prediction_prob]
                dataframe_input['Prob_1'] = [item[1] for item in Exited_prediction_prob]
                # dataframe_input['Exited'] = Exited_prediction_prob
                st.write(dataframe_input)
            else:
                st.error("Prediction failed. Please check the prediction function.")
        else:
            st.error("Failed to load CSV. Please check the input.")
        