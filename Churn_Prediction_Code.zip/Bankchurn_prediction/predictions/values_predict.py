import streamlit as st
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
import numpy as np
import pandas as pd
import pickle

# st.set_page_config(
#     layout= 'centered',
#     page_title= 'churn_prediction'
# )

rf = pickle.load(open('model.pkl','rb'))

def predict_values(dict):
    
    del dict['CustomerId']
    del dict['Surname']
    
    dict['Gender'] = {'Male': 0, 'Female': 1}.get(dict['Gender'], -1)
    dict['Geography'] = {'France': 0, 'Germany': 1, 'Spain': 2}.get(dict['Geography'], -1)

    
    values_list = list(dict.values())
    X_numerical = np.array(values_list).reshape(1, -1)
    
    prediction = rf.predict(X_numerical)[0] # Predict for each row of scaled data

    return prediction