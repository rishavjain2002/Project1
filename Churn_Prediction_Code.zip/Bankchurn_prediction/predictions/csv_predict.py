import streamlit as st
import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
import pickle

# st.set_page_config(
#     layout= 'centered',
#     page_title= 'churn_prediction'
# )


rf = pickle.load(open('model.pkl','rb'))


def predict_csv(df):
    if df is not None and not df.empty:
        main_input = df
        X_input = main_input.drop(['RowNumber', 'Surname', 'CustomerId'], axis=1)

        X_input['Gender'] = X_input['Gender'].replace({'Male':0,'Female':1})
        X_input['Geography'] = X_input['Geography'].replace({'France':0,'Germany':1,'Spain':2})
        
        predicted_results = rf.predict_proba(X_input)
        return predicted_results